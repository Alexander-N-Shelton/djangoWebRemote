Django WebRemote - Installer Package
====================================

This package installs Django WebRemote on your local machine or Raspberry Pi.

WebRemote allows you to control your smart TV over your home network using any device with a browser.

---------------------
Included in this zip:
---------------------
- install.sh ........ Main installation script
- logo.png ........ Django WebRemote Logo
- README.txt ......... This file

---------------------
Quick Start:
---------------------

1. Extract the zip:
   unzip djangoWebRemote-installer.zip
   cd djangoWebRemote-installer

2. Make the install script executable:
   chmod +x install.sh

3. Run the installer:
   ./install.sh

4. Follow on-screen instructions

---------------------
Notes:
---------------------
- This is a local installation. No data is sent outside your network.
- Tested on Linux systems
- For updates and support, visit:
  https://alexander-n-shelton.github.io/djangoWebRemote/

---------------------
License:
---------------------
MIT License - See LICENSE file (if included)
